import { useState, useEffect, useRef } from "react";

// ── Colour tokens ────────────────────────────────────────────────────────────
const C = {
  bg0: "#060d1f",
  bg1: "#0b1530",
  bg2: "#101d3d",
  card: "#0f1c3a",
  cardBright: "#162145",
  border: "#1e2f57",
  accent: "#f5a623",
  accentGold: "#ffd700",
  accentGlow: "#f5a62366",
  green: "#00e676",
  greenDark: "#00a152",
  red: "#ff3d57",
  redDark: "#b71c1c",
  violet: "#7c4dff",
  cyan: "#00e5ff",
  pink: "#ff4081",
  text: "#e8eaf6",
  textMuted: "#8899bb",
  textDim: "#4a5880",
  navBg: "#070f24ee",
};

// ── Inline styles ────────────────────────────────────────────────────────────
const S = {
  root: {
    fontFamily: "'Inter', 'Segoe UI', sans-serif",
    background: C.bg0,
    color: C.text,
    minHeight: "100vh",
    maxWidth: 430,
    margin: "0 auto",
    position: "relative",
    overflowX: "hidden",
    paddingBottom: 72,
  },
  topBar: {
    background: `linear-gradient(135deg, ${C.bg1} 0%, ${C.bg2} 100%)`,
    padding: "10px 16px 0",
    borderBottom: `1px solid ${C.border}`,
  },
  logo: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    marginBottom: 6,
  },
  logoText: {
    fontSize: 22,
    fontWeight: 800,
    letterSpacing: 1,
    background: `linear-gradient(90deg, ${C.accentGold}, ${C.accent})`,
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
  },
  logoFlag: { fontSize: 22 },
  noticeBar: {
    background: `linear-gradient(90deg, #1a2a50, #1e3260)`,
    padding: "5px 12px",
    display: "flex",
    alignItems: "center",
    gap: 8,
    fontSize: 12,
    color: C.accentGold,
    overflow: "hidden",
    borderBottom: `1px solid ${C.border}`,
  },
  noticeIcon: { fontSize: 14, flexShrink: 0 },
  noticeScroll: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    flex: 1,
  },
  walletCard: {
    margin: "12px 16px",
    background: `linear-gradient(135deg, #0e2060 0%, #1a3a80 50%, #0e2060 100%)`,
    borderRadius: 16,
    padding: "16px 20px",
    border: `1px solid #2a4a90`,
    boxShadow: `0 4px 24px #0006`,
    position: "relative",
    overflow: "hidden",
  },
  walletGlow: {
    position: "absolute",
    top: -40,
    right: -40,
    width: 120,
    height: 120,
    borderRadius: "50%",
    background: `radial-gradient(circle, ${C.accentGlow}, transparent)`,
    pointerEvents: "none",
  },
  walletLabel: { fontSize: 11, color: C.textMuted, marginBottom: 2 },
  walletAmount: {
    fontSize: 32,
    fontWeight: 800,
    color: C.accentGold,
    letterSpacing: 1,
    lineHeight: 1.1,
  },
  walletRupee: { fontSize: 20, fontWeight: 600 },
  walletRow: { display: "flex", gap: 10, marginTop: 14 },
  walletBtn: (color, bg) => ({
    flex: 1,
    padding: "10px 0",
    borderRadius: 10,
    border: "none",
    cursor: "pointer",
    fontWeight: 700,
    fontSize: 14,
    color,
    background: bg,
    transition: "opacity 0.15s, transform 0.15s",
    boxShadow: `0 2px 12px #0005`,
  }),
  bonusBanner: {
    margin: "0 16px 12px",
    borderRadius: 16,
    overflow: "hidden",
    position: "relative",
    background: `linear-gradient(120deg, #1a0a30, #2a0a5a, #1a0a30)`,
    border: `1px solid #4a1a8a`,
    boxShadow: `0 4px 20px #4a1a8a44`,
    padding: "18px 16px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    cursor: "pointer",
  },
  bonusLeft: {},
  bonusTag: {
    display: "inline-block",
    background: `linear-gradient(90deg, ${C.accentGold}, ${C.accent})`,
    color: "#111",
    fontSize: 10,
    fontWeight: 800,
    padding: "2px 8px",
    borderRadius: 20,
    marginBottom: 6,
    letterSpacing: 1,
  },
  bonusTitle: { fontSize: 20, fontWeight: 800, color: "#fff", lineHeight: 1.2 },
  bonusHighlight: { color: C.accentGold },
  bonusSub: { fontSize: 11, color: "#c0a0ff", marginTop: 4 },
  bonusBtn: {
    background: `linear-gradient(135deg, ${C.accentGold}, ${C.accent})`,
    color: "#111",
    border: "none",
    borderRadius: 10,
    padding: "10px 16px",
    fontWeight: 800,
    fontSize: 13,
    cursor: "pointer",
    whiteSpace: "nowrap",
    boxShadow: `0 4px 16px ${C.accentGlow}`,
  },
  bonusStars: {
    position: "absolute",
    top: 8,
    right: 80,
    fontSize: 18,
    opacity: 0.3,
  },
  sectionHead: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "4px 16px 10px",
  },
  sectionTitle: { fontSize: 15, fontWeight: 700, color: C.text },
  sectionAll: { fontSize: 12, color: C.accent, cursor: "pointer" },
  catRow: {
    display: "flex",
    gap: 8,
    padding: "0 16px 14px",
    overflowX: "auto",
    scrollbarWidth: "none",
  },
  catPill: (active) => ({
    padding: "8px 16px",
    borderRadius: 24,
    border: `1px solid ${active ? C.accent : C.border}`,
    background: active ? `linear-gradient(135deg, ${C.accent}22, ${C.accentGold}11)` : C.card,
    color: active ? C.accentGold : C.textMuted,
    fontSize: 12,
    fontWeight: active ? 700 : 500,
    whiteSpace: "nowrap",
    cursor: "pointer",
    transition: "all 0.2s",
    flexShrink: 0,
  }),
  gameGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: 10,
    padding: "0 16px 16px",
  },
  gameCard: (grad) => ({
    borderRadius: 14,
    overflow: "hidden",
    background: grad,
    border: `1px solid ${C.border}`,
    cursor: "pointer",
    transition: "transform 0.15s",
    boxShadow: `0 4px 16px #0004`,
    position: "relative",
  }),
  gameCardInner: {
    padding: "14px 10px 10px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 4,
  },
  gameEmoji: { fontSize: 28 },
  gameName: { fontSize: 11, fontWeight: 700, color: "#fff", textAlign: "center", lineHeight: 1.2 },
  gameTag: {
    fontSize: 9,
    fontWeight: 700,
    padding: "2px 6px",
    borderRadius: 10,
    marginTop: 2,
  },
  platformScroll: {
    display: "flex",
    gap: 10,
    padding: "0 16px 16px",
    overflowX: "auto",
    scrollbarWidth: "none",
  },
  platformCard: (grad) => ({
    flexShrink: 0,
    width: 140,
    borderRadius: 14,
    background: grad,
    border: `1px solid ${C.border}`,
    padding: "14px 12px",
    cursor: "pointer",
    transition: "transform 0.15s",
    boxShadow: `0 4px 16px #0004`,
  }),
  platformIcon: { fontSize: 26, marginBottom: 4 },
  platformName: { fontSize: 13, fontWeight: 700, color: "#fff", marginBottom: 2 },
  platformSub: { fontSize: 10, color: C.textMuted },
  platformBadge: {
    display: "inline-block",
    background: C.green,
    color: "#000",
    fontSize: 9,
    fontWeight: 800,
    padding: "2px 6px",
    borderRadius: 10,
    marginTop: 6,
  },
  bottomNav: {
    position: "fixed",
    bottom: 0,
    left: "50%",
    transform: "translateX(-50%)",
    width: "100%",
    maxWidth: 430,
    background: C.navBg,
    borderTop: `1px solid ${C.border}`,
    display: "flex",
    backdropFilter: "blur(12px)",
    zIndex: 100,
  },
  navItem: (active) => ({
    flex: 1,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "8px 0 6px",
    cursor: "pointer",
    gap: 3,
    position: "relative",
  }),
  navIcon: (active) => ({
    fontSize: 22,
    filter: active ? `drop-shadow(0 0 6px ${C.accent})` : "none",
    transition: "filter 0.2s",
  }),
  navLabel: (active) => ({
    fontSize: 10,
    fontWeight: active ? 700 : 500,
    color: active ? C.accentGold : C.textMuted,
    letterSpacing: 0.3,
    transition: "color 0.2s",
  }),
  navDot: {
    position: "absolute",
    top: 4,
    right: "22%",
    width: 6,
    height: 6,
    borderRadius: "50%",
    background: C.red,
  },
  timerRing: (pct, color) => ({
    width: 90,
    height: 90,
    borderRadius: "50%",
    background: `conic-gradient(${color} ${pct * 3.6}deg, #1a2a50 0deg)`,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: `0 0 20px ${color}66`,
    position: "relative",
  }),
  timerInner: {
    width: 70,
    height: 70,
    borderRadius: "50%",
    background: C.bg1,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  betBtn: (col, bg) => ({
    flex: 1,
    padding: "14px 0",
    borderRadius: 12,
    border: "none",
    cursor: "pointer",
    fontWeight: 800,
    fontSize: 15,
    color: col,
    background: bg,
    boxShadow: `0 4px 16px ${bg}66`,
    transition: "transform 0.1s, box-shadow 0.1s",
    letterSpacing: 0.5,
  }),
  tableRow: (alt) => ({
    display: "grid",
    gridTemplateColumns: "2fr 1.5fr 1fr 1fr",
    gap: 4,
    padding: "10px 12px",
    background: alt ? C.card : C.bg1,
    borderBottom: `1px solid ${C.border}`,
    fontSize: 12,
    alignItems: "center",
  }),
  profileCard: {
    margin: "12px 16px",
    background: `linear-gradient(135deg, #0e2060, #162880)`,
    borderRadius: 16,
    padding: "20px",
    border: `1px solid #2a4a90`,
    display: "flex",
    alignItems: "center",
    gap: 14,
    boxShadow: `0 4px 24px #0006`,
  },
  avatarRing: {
    width: 60,
    height: 60,
    borderRadius: "50%",
    background: `linear-gradient(135deg, ${C.accentGold}, ${C.accent})`,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 28,
    flexShrink: 0,
    boxShadow: `0 0 16px ${C.accentGlow}`,
  },
  menuItem: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "14px 16px",
    background: C.card,
    borderBottom: `1px solid ${C.border}`,
    cursor: "pointer",
    transition: "background 0.15s",
  },
  menuLeft: { display: "flex", alignItems: "center", gap: 12 },
  menuIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 18,
  },
  menuText: { fontSize: 14, fontWeight: 500 },
  promoCard: (grad) => ({
    margin: "0 16px 12px",
    borderRadius: 14,
    background: grad,
    border: `1px solid ${C.border}`,
    padding: "16px",
    boxShadow: `0 4px 16px #0004`,
    cursor: "pointer",
  }),
  promoTitle: { fontSize: 16, fontWeight: 800, marginBottom: 4 },
  promoSub: { fontSize: 12, color: C.textMuted, marginBottom: 12 },
  promoBtn: {
    display: "inline-block",
    padding: "8px 16px",
    borderRadius: 20,
    border: `1px solid ${C.accentGold}`,
    color: C.accentGold,
    fontSize: 12,
    fontWeight: 700,
    cursor: "pointer",
    background: "transparent",
  },
};

// ── Data ─────────────────────────────────────────────────────────────────────
const CATEGORIES = ["🔥 Popular", "🎰 Slots", "🃏 Rummy", "🎲 Casino", "🎯 Lottery", "🐟 Fishing"];

const GAMES = [
  { name: "Color Trading", emoji: "🎨", tag: "HOT", tagColor: C.red, tagBg: "#ff3d5722", grad: `linear-gradient(135deg, #1a0030, #3d0060)` },
  { name: "Teen Patti", emoji: "🃏", tag: "LIVE", tagColor: C.green, tagBg: "#00e67622", grad: `linear-gradient(135deg, #001a30, #003060)` },
  { name: "Lucky Spin", emoji: "🎡", tag: "NEW", tagColor: C.cyan, tagBg: "#00e5ff22", grad: `linear-gradient(135deg, #001530, #003060)` },
  { name: "Rummy Gold", emoji: "♠️", tag: "TOP", tagColor: C.accentGold, tagBg: "#ffd70022", grad: `linear-gradient(135deg, #1a1000, #3a2500)` },
  { name: "Dragon Tiger", emoji: "🐉", tag: "HOT", tagColor: C.red, tagBg: "#ff3d5722", grad: `linear-gradient(135deg, #1a0500, #3a0f00)` },
  { name: "Fish Hunter", emoji: "🐠", tag: "FUN", tagColor: C.pink, tagBg: "#ff408122", grad: `linear-gradient(135deg, #001520, #002a40)` },
  { name: "Aviator", emoji: "✈️", tag: "CRASH", tagColor: C.violet, tagBg: "#7c4dff22", grad: `linear-gradient(135deg, #0a0020, #1a0040)` },
  { name: "Andar Bahar", emoji: "🀄", tag: "LIVE", tagColor: C.green, tagBg: "#00e67622", grad: `linear-gradient(135deg, #001a10, #003020)` },
  { name: "Lottery", emoji: "🏆", tag: "WIN", tagColor: C.accentGold, tagBg: "#ffd70022", grad: `linear-gradient(135deg, #1a1500, #352a00)` },
];

const PLATFORMS = [
  { name: "Tiranga Games", icon: "🇮🇳", sub: "Color, Win Go", badge: "Recommended", grad: `linear-gradient(135deg, #0e1e50, #162880)` },
  { name: "Jili Slots", icon: "🎰", sub: "Slots & Fishing", badge: "Popular", grad: `linear-gradient(135deg, #1a0520, #350a40)` },
  { name: "Evolution", icon: "📺", sub: "Live Casino", badge: "HD Live", grad: `linear-gradient(135deg, #1a0500, #3a0f00)` },
  { name: "Spribe", icon: "✈️", sub: "Crash Games", badge: "Trending", grad: `linear-gradient(135deg, #051a0e, #0a3020)` },
];

const HISTORY = [
  { period: "20241225001", open: "🟢 Green", amount: "₹500", result: "+₹450", win: true },
  { period: "20241225002", open: "🔴 Red", amount: "₹200", result: "-₹200", win: false },
  { period: "20241225003", open: "🟣 Violet", amount: "₹1000", result: "+₹4500", win: true },
  { period: "20241225004", open: "🟢 Green", amount: "₹300", result: "+₹270", win: true },
  { period: "20241225005", open: "🔴 Red", amount: "₹500", result: "-₹500", win: false },
];

const AMOUNTS = [10, 20, 50, 100, 200, 500];

// ── ScrollNotice ──────────────────────────────────────────────────────────────
function ScrollNotice() {
  const notices = [
    "🎉 Congratulations Raj***! Won ₹1,25,000 in Color Trading!",
    "🏆 New User Bonus: Get ₹50 FREE on registration!",
    "💰 Priya*** just withdrew ₹87,000 successfully!",
    "🎰 VIP Level 5 unlocked extra 15% bonus!",
    "🔥 Big Winner! Arjun*** won ₹5,00,000 in Lottery!",
  ];
  const text = notices.join("   ⭐   ");
  const [offset, setOffset] = useState(0);
  const ref = useRef(null);

  useEffect(() => {
    let id;
    const step = () => {
      setOffset((o) => {
        if (ref.current) {
          const w = ref.current.scrollWidth / 2;
          return o <= -w ? 0 : o - 0.6;
        }
        return o - 0.6;
      });
      id = requestAnimationFrame(step);
    };
    id = requestAnimationFrame(step);
    return () => cancelAnimationFrame(id);
  }, []);

  return (
    <div style={S.noticeBar}>
      <span style={S.noticeIcon}>📢</span>
      <div style={S.noticeScroll}>
        <span
          ref={ref}
          style={{ display: "inline-block", transform: `translateX(${offset}px)`, transition: "none" }}
        >
          {text}&nbsp;&nbsp;&nbsp;&nbsp;{text}
        </span>
      </div>
    </div>
  );
}

// ── WalletCard ────────────────────────────────────────────────────────────────
function WalletCard() {
  const [showAmt, setShowAmt] = useState(true);
  return (
    <div style={S.walletCard}>
      <div style={S.walletGlow} />
      <div style={{ position: "relative" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={S.walletLabel}>Total Balance</div>
            <div style={S.walletAmount}>
              <span style={S.walletRupee}>₹</span>
              {showAmt ? "12,450.00" : "••••••"}
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button
              onClick={() => setShowAmt(!showAmt)}
              style={{
                background: "none",
                border: `1px solid ${C.border}`,
                color: C.textMuted,
                borderRadius: 8,
                padding: "4px 8px",
                cursor: "pointer",
                fontSize: 12,
              }}
            >
              {showAmt ? "Hide" : "Show"}
            </button>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 10, color: C.textMuted }}>VIP Level</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.accentGold }}>⭐ VIP 3</div>
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 20, marginTop: 10 }}>
          <div>
            <div style={{ fontSize: 10, color: C.textMuted }}>Today Win</div>
            <div style={{ fontSize: 13, color: C.green, fontWeight: 700 }}>+₹1,200</div>
          </div>
          <div>
            <div style={{ fontSize: 10, color: C.textMuted }}>Bonus</div>
            <div style={{ fontSize: 13, color: C.cyan, fontWeight: 700 }}>₹450</div>
          </div>
          <div>
            <div style={{ fontSize: 10, color: C.textMuted }}>Turnover</div>
            <div style={{ fontSize: 13, color: C.textMuted, fontWeight: 700 }}>₹8,500</div>
          </div>
        </div>
        <div style={S.walletRow}>
          <button style={S.walletBtn("#111", `linear-gradient(135deg, ${C.accentGold}, ${C.accent})`)}>
            ⚡ Deposit
          </button>
          <button style={S.walletBtn(C.text, `linear-gradient(135deg, #1a3060, #2a4a90)`)}>
            💸 Withdraw
          </button>
          <button style={S.walletBtn(C.textMuted, C.card)}>🔄 Refresh</button>
        </div>
      </div>
    </div>
  );
}

// ── HomePage ──────────────────────────────────────────────────────────────────
function HomePage({ goTo }) {
  const [cat, setCat] = useState(0);
  return (
    <div>
      {/* Bonus Banner */}
      <div style={S.bonusBanner} onClick={() => goTo("color")}>
        <span style={S.bonusStars}>✨✨✨</span>
        <div style={S.bonusLeft}>
          <div style={S.bonusTag}>🔥 LIMITED TIME</div>
          <div style={S.bonusTitle}>
            First Deposit <br />
            <span style={S.bonusHighlight}>+300% BONUS</span>
          </div>
          <div style={S.bonusSub}>Min ₹100 · Instant Credit</div>
        </div>
        <button style={S.bonusBtn}>CLAIM NOW →</button>
      </div>

      {/* Categories */}
      <div style={S.catRow}>
        {CATEGORIES.map((c, i) => (
          <div key={i} style={S.catPill(cat === i)} onClick={() => setCat(i)}>
            {c}
          </div>
        ))}
      </div>

      {/* Games */}
      <div style={S.sectionHead}>
        <span style={S.sectionTitle}>🎮 Games</span>
        <span style={S.sectionAll}>View All →</span>
      </div>
      <div style={S.gameGrid}>
        {GAMES.map((g, i) => (
          <div key={i} style={S.gameCard(g.grad)} onClick={() => i === 0 && goTo("color")}>
            <div style={S.gameCardInner}>
              <span style={S.gameEmoji}>{g.emoji}</span>
              <span style={S.gameName}>{g.name}</span>
              <span style={{ ...S.gameTag, color: g.tagColor, background: g.tagBg }}>{g.tag}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Platforms */}
      <div style={S.sectionHead}>
        <span style={S.sectionTitle}>🏆 Top Platforms</span>
        <span style={S.sectionAll}>View All →</span>
      </div>
      <div style={S.platformScroll}>
        {PLATFORMS.map((p, i) => (
          <div key={i} style={S.platformCard(p.grad)}>
            <div style={S.platformIcon}>{p.icon}</div>
            <div style={S.platformName}>{p.name}</div>
            <div style={S.platformSub}>{p.sub}</div>
            <span style={S.platformBadge}>{p.badge}</span>
          </div>
        ))}
      </div>

      {/* Live Stats */}
      <div style={S.sectionHead}>
        <span style={S.sectionTitle}>📊 Live Stats</span>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, padding: "0 16px 16px" }}>
        {[
          { label: "Online Now", val: "12,840", icon: "👥", color: C.green },
          { label: "Today Wins", val: "₹48L", icon: "💰", color: C.accentGold },
          { label: "Total Players", val: "2.1M+", icon: "🏆", color: C.cyan },
        ].map((s, i) => (
          <div
            key={i}
            style={{
              background: C.card,
              borderRadius: 12,
              padding: "12px 8px",
              textAlign: "center",
              border: `1px solid ${C.border}`,
            }}
          >
            <div style={{ fontSize: 20, marginBottom: 4 }}>{s.icon}</div>
            <div style={{ fontSize: 13, fontWeight: 800, color: s.color }}>{s.val}</div>
            <div style={{ fontSize: 10, color: C.textMuted, marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── ColorTradingPage ──────────────────────────────────────────────────────────
function ColorTradingPage() {
  const [seconds, setSeconds] = useState(47);
  const [selected, setSelected] = useState(null);
  const [amount, setAmount] = useState(10);
  const [round, setRound] = useState("20241225006");
  const [bets, setBets] = useState([]);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    const id = setInterval(() => {
      setSeconds((s) => {
        if (s <= 1) {
          setRound((r) => String(Number(r) + 1).padStart(11, "0"));
          return 60;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, []);

  const pct = (seconds / 60) * 100;
  const timerColor = seconds > 20 ? C.green : seconds > 10 ? C.accent : C.red;

  const placeBet = () => {
    if (!selected) return;
    const won = Math.random() > 0.4;
    const mult = selected === "Violet" ? 4.5 : 2;
    const result = won ? `+₹${(amount * mult * 0.9).toFixed(0)}` : `-₹${amount}`;
    setBets((b) =>
      [{ period: round, open: selected, amount: `₹${amount}`, result, win: won }, ...b].slice(0, 5)
    );
    showToast(won ? `🎉 You won ${result}!` : `😢 Better luck next time!`, won ? C.green : C.red);
    setSelected(null);
  };

  const showToast = (msg, color) => {
    setToast({ msg, color });
    setTimeout(() => setToast(null), 2500);
  };

  return (
    <div>
      {toast && (
        <div
          style={{
            position: "fixed",
            top: 80,
            left: "50%",
            transform: "translateX(-50%)",
            background: toast.color,
            color: "#fff",
            padding: "10px 20px",
            borderRadius: 12,
            fontWeight: 700,
            zIndex: 999,
            boxShadow: "0 4px 20px #0006",
            whiteSpace: "nowrap",
          }}
        >
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div
        style={{
          padding: "14px 16px 10px",
          background: `linear-gradient(135deg, ${C.bg1}, ${C.bg2})`,
          borderBottom: `1px solid ${C.border}`,
        }}
      >
        <div style={{ fontSize: 16, fontWeight: 800 }}>🎨 Color Trading</div>
        <div style={{ fontSize: 11, color: C.textMuted }}>Period: {round}</div>
      </div>

      {/* Timer */}
      <div
        style={{
          background: C.bg1,
          margin: "12px 16px",
          borderRadius: 16,
          padding: "20px 16px",
          border: `1px solid ${C.border}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div style={{ textAlign: "center" }}>
          <div style={S.timerRing(pct, timerColor)}>
            <div style={S.timerInner}>
              <div style={{ fontSize: 22, fontWeight: 900, color: timerColor, lineHeight: 1 }}>
                {String(seconds).padStart(2, "0")}
              </div>
              <div style={{ fontSize: 9, color: C.textMuted }}>seconds</div>
            </div>
          </div>
          <div style={{ fontSize: 11, color: C.textMuted, marginTop: 8 }}>Time Left</div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Last Result</div>
          {["🟢", "🔴", "🟢", "🟣", "🔴"].map((e, i) => (
            <span key={i} style={{ fontSize: 16, margin: "0 2px" }}>{e}</span>
          ))}
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 11, color: C.textMuted }}>Today Profit</div>
          <div style={{ fontSize: 20, fontWeight: 800, color: C.green }}>+₹4,200</div>
          <div style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>Win Rate</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: C.cyan }}>62.4%</div>
        </div>
      </div>

      {/* Bet Buttons */}
      <div style={{ padding: "0 16px 12px" }}>
        <div style={{ fontSize: 13, color: C.textMuted, marginBottom: 10 }}>Select Color to Bet</div>
        <div style={{ display: "flex", gap: 8 }}>
          {[
            { name: "Green", emoji: "🟢", bg: `linear-gradient(135deg, ${C.greenDark}, ${C.green})`, col: "#fff", mult: "2x" },
            { name: "Violet", emoji: "🟣", bg: `linear-gradient(135deg, #4a00c0, ${C.violet})`, col: "#fff", mult: "4.5x" },
            { name: "Red", emoji: "🔴", bg: `linear-gradient(135deg, ${C.redDark}, ${C.red})`, col: "#fff", mult: "2x" },
          ].map((b) => (
            <button
              key={b.name}
              style={{
                ...S.betBtn(b.col, selected === b.name ? b.bg : C.card),
                flex: 1,
                border: selected === b.name ? "2px solid #fff8" : `1px solid ${C.border}`,
                transform: selected === b.name ? "scale(1.03)" : "scale(1)",
              }}
              onClick={() => setSelected(b.name)}
            >
              {b.emoji} {b.name}
              <br />
              <span style={{ fontSize: 11, opacity: 0.8 }}>{b.mult} payout</span>
            </button>
          ))}
        </div>
      </div>

      {/* Amount */}
      <div style={{ padding: "0 16px 12px" }}>
        <div style={{ fontSize: 13, color: C.textMuted, marginBottom: 8 }}>Bet Amount</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {AMOUNTS.map((a) => (
            <button
              key={a}
              style={{
                padding: "8px 14px",
                borderRadius: 8,
                border: amount === a ? `1px solid ${C.accent}` : `1px solid ${C.border}`,
                background: amount === a ? `${C.accent}22` : C.card,
                color: amount === a ? C.accentGold : C.textMuted,
                fontWeight: 700,
                cursor: "pointer",
                fontSize: 13,
              }}
              onClick={() => setAmount(a)}
            >
              ₹{a}
            </button>
          ))}
        </div>
      </div>

      {/* Place Bet */}
      <div style={{ padding: "0 16px 16px" }}>
        <button
          onClick={placeBet}
          style={{
            width: "100%",
            padding: "14px 0",
            borderRadius: 12,
            border: "none",
            cursor: "pointer",
            fontWeight: 800,
            fontSize: 16,
            color: "#111",
            background: selected ? `linear-gradient(135deg, ${C.accentGold}, ${C.accent})` : "#333",
            boxShadow: selected ? `0 4px 20px ${C.accentGlow}` : "none",
            transition: "all 0.2s",
            letterSpacing: 1,
          }}
        >
          {selected ? `BET ₹${amount} ON ${selected.toUpperCase()} →` : "SELECT A COLOR TO BET"}
        </button>
      </div>

      {/* History */}
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>📋 My Bet History</div>
        <div style={{ borderRadius: 12, overflow: "hidden", border: `1px solid ${C.border}` }}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "2fr 1.5fr 1fr 1fr",
              gap: 4,
              padding: "8px 12px",
              background: C.bg2,
              fontSize: 11,
              color: C.textMuted,
              fontWeight: 700,
            }}
          >
            <span>Period</span>
            <span>Color</span>
            <span>Bet</span>
            <span>Result</span>
          </div>
          {[...bets, ...HISTORY].slice(0, 5).map((h, i) => (
            <div key={i} style={S.tableRow(i % 2)}>
              <span style={{ fontSize: 10, color: C.textDim }}>{h.period.slice(-5)}</span>
              <span>{h.open}</span>
              <span style={{ color: C.textMuted }}>{h.amount}</span>
              <span style={{ fontWeight: 700, color: h.win ? C.green : C.red }}>{h.result}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── PromotionPage ─────────────────────────────────────────────────────────────
function PromotionPage() {
  return (
    <div style={{ paddingTop: 12 }}>
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 4 }}>🎁 Promotions</div>
        <div style={{ fontSize: 12, color: C.textMuted }}>Exclusive bonuses for you</div>
      </div>
      {[
        { title: "First Deposit +300%", sub: "Min ₹100 · Up to ₹50,000 bonus", emoji: "💎", grad: `linear-gradient(135deg, #1a0040, #3d0080)` },
        { title: "Daily Login Bonus", sub: "Login every day to collect rewards", emoji: "📅", grad: `linear-gradient(135deg, #001a30, #003060)` },
        { title: "Referral Reward", sub: "Earn ₹200 for every friend you invite", emoji: "👥", grad: `linear-gradient(135deg, #001a10, #003020)` },
        { title: "VIP Cashback", sub: "Get up to 15% cashback weekly", emoji: "⭐", grad: `linear-gradient(135deg, #1a1000, #3a2500)` },
        { title: "Lucky Draw", sub: "Play for a chance to win ₹10 Lakh", emoji: "🎰", grad: `linear-gradient(135deg, #1a0010, #3a0020)` },
      ].map((p, i) => (
        <div key={i} style={S.promoCard(p.grad)}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ fontSize: 22, marginBottom: 6 }}>{p.emoji}</div>
              <div style={S.promoTitle}>{p.title}</div>
              <div style={S.promoSub}>{p.sub}</div>
              <button style={S.promoBtn}>Claim Now →</button>
            </div>
            <div style={{ fontSize: 40, opacity: 0.15 }}>{p.emoji}</div>
          </div>
        </div>
      ))}

      {/* Referral */}
      <div
        style={{
          margin: "0 16px 16px",
          background: `linear-gradient(135deg, #0a1a3a, #142860)`,
          borderRadius: 14,
          padding: "16px",
          border: `1px solid ${C.border}`,
        }}
      >
        <div style={{ fontSize: 14, fontWeight: 800, marginBottom: 4 }}>🔗 Your Referral Code</div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            background: C.bg0,
            borderRadius: 10,
            padding: "10px 12px",
            marginTop: 8,
          }}
        >
          <span style={{ flex: 1, fontSize: 16, fontWeight: 800, letterSpacing: 3, color: C.accentGold }}>
            TRNGS7842
          </span>
          <button
            style={{
              background: C.accent,
              color: "#111",
              border: "none",
              borderRadius: 8,
              padding: "6px 12px",
              fontWeight: 700,
              cursor: "pointer",
              fontSize: 12,
            }}
          >
            Copy
          </button>
        </div>
        <div style={{ fontSize: 11, color: C.textMuted, marginTop: 8 }}>
          Share your code · Earn ₹200 per referral
        </div>
      </div>
    </div>
  );
}

// ── ActivityPage ──────────────────────────────────────────────────────────────
function ActivityPage() {
  return (
    <div style={{ paddingTop: 12 }}>
      <div style={{ padding: "0 16px 16px" }}>
        <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 4 }}>📊 Activity</div>
        <div style={{ fontSize: 12, color: C.textMuted }}>Your gaming activity & earnings</div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, padding: "0 16px 16px" }}>
        {[
          { label: "Total Bets", val: "1,247", icon: "🎲", color: C.cyan },
          { label: "Total Wins", val: "762", icon: "🏆", color: C.green },
          { label: "Best Win", val: "₹12,500", icon: "💎", color: C.accentGold },
          { label: "Win Rate", val: "61.1%", icon: "📈", color: C.violet },
        ].map((s, i) => (
          <div
            key={i}
            style={{
              background: C.card,
              borderRadius: 12,
              padding: 14,
              border: `1px solid ${C.border}`,
              display: "flex",
              gap: 10,
              alignItems: "center",
            }}
          >
            <div style={{ fontSize: 24 }}>{s.icon}</div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 800, color: s.color }}>{s.val}</div>
              <div style={{ fontSize: 11, color: C.textMuted }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Transactions */}
      <div style={{ padding: "0 16px 8px" }}>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 10 }}>💳 Recent Transactions</div>
        {[
          { type: "Deposit", amt: "+₹5,000", date: "Today 14:32", icon: "⬇️", color: C.green },
          { type: "Color Win", amt: "+₹4,500", date: "Today 13:15", icon: "🎨", color: C.green },
          { type: "Color Bet", amt: "-₹1,000", date: "Today 12:58", icon: "🎲", color: C.red },
          { type: "Withdrawal", amt: "-₹3,000", date: "Yesterday", icon: "⬆️", color: C.red },
          { type: "Referral", amt: "+₹200", date: "Yesterday", icon: "👥", color: C.cyan },
        ].map((t, i) => (
          <div
            key={i}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "12px 0",
              borderBottom: `1px solid ${C.border}`,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 10,
                  background: C.card,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 18,
                }}
              >
                {t.icon}
              </div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{t.type}</div>
                <div style={{ fontSize: 11, color: C.textMuted }}>{t.date}</div>
              </div>
            </div>
            <div style={{ fontWeight: 800, color: t.color, fontSize: 14 }}>{t.amt}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── AccountPage ───────────────────────────────────────────────────────────────
function AccountPage() {
  const menus = [
    { icon: "👤", label: "My Profile", emoji: "👤", bg: `linear-gradient(135deg, #0e2060, #1a3a80)` },
    { icon: "💳", label: "Bank Account", emoji: "💳", bg: `linear-gradient(135deg, #002060, #004090)` },
    { icon: "📜", label: "Bet History", emoji: "📜", bg: `linear-gradient(135deg, #1a0040, #350080)` },
    { icon: "💰", label: "Transaction History", emoji: "💰", bg: `linear-gradient(135deg, #001a30, #003060)` },
    { icon: "⭐", label: "VIP Center", emoji: "⭐", bg: `linear-gradient(135deg, #1a1000, #3a2500)` },
    { icon: "👥", label: "Invite Friends", emoji: "👥", bg: `linear-gradient(135deg, #001a10, #003020)` },
    { icon: "🔔", label: "Notifications", emoji: "🔔", bg: `linear-gradient(135deg, #1a0010, #3a0030)` },
    { icon: "💬", label: "Customer Support", emoji: "💬", bg: `linear-gradient(135deg, #001020, #002040)` },
    { icon: "⚙️", label: "Settings", emoji: "⚙️", bg: `linear-gradient(135deg, #0a0a20, #1a1a40)` },
  ];

  return (
    <div>
      {/* Profile */}
      <div style={S.profileCard}>
        <div style={S.avatarRing}>👤</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 800 }}>Rajesh Kumar</div>
          <div style={{ fontSize: 12, color: C.textMuted }}>ID: 7842391</div>
          <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
            <span
              style={{
                fontSize: 11,
                background: `${C.accentGold}22`,
                color: C.accentGold,
                padding: "2px 8px",
                borderRadius: 10,
                fontWeight: 700,
              }}
            >
              ⭐ VIP 3
            </span>
            <span
              style={{
                fontSize: 11,
                background: `${C.green}22`,
                color: C.green,
                padding: "2px 8px",
                borderRadius: 10,
              }}
            >
              ✓ Verified
            </span>
          </div>
        </div>
        <div style={{ color: C.textMuted, fontSize: 18 }}>›</div>
      </div>

      {/* Quick Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, padding: "0 16px 16px" }}>
        {[
          { label: "Balance", val: "₹12,450", color: C.accentGold },
          { label: "Total Win", val: "₹1.2L", color: C.green },
          { label: "Referrals", val: "14", color: C.cyan },
        ].map((s, i) => (
          <div
            key={i}
            style={{
              background: C.card,
              borderRadius: 12,
              padding: "12px 8px",
              textAlign: "center",
              border: `1px solid ${C.border}`,
            }}
          >
            <div style={{ fontSize: 14, fontWeight: 800, color: s.color }}>{s.val}</div>
            <div style={{ fontSize: 10, color: C.textMuted }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Menu */}
      <div style={{ borderRadius: 16, overflow: "hidden", margin: "0 16px 16px", border: `1px solid ${C.border}` }}>
        {menus.map((m, i) => (
          <div key={i} style={S.menuItem}>
            <div style={S.menuLeft}>
              <div style={{ ...S.menuIcon, background: m.bg }}>{m.emoji}</div>
              <span style={S.menuText}>{m.label}</span>
            </div>
            <span style={{ color: C.textDim }}>›</span>
          </div>
        ))}
      </div>

      <div style={{ padding: "0 16px 16px" }}>
        <button
          style={{
            width: "100%",
            padding: "14px 0",
            borderRadius: 12,
            border: `1px solid ${C.red}44`,
            background: `${C.red}11`,
            color: C.red,
            fontWeight: 700,
            cursor: "pointer",
            fontSize: 14,
          }}
        >
          🚪 Log Out
        </button>
      </div>
    </div>
  );
}

// ── App ───────────────────────────────────────────────────────────────────────
const TABS = [
  { id: "home", label: "Home", icon: "🏠" },
  { id: "activity", label: "Activity", icon: "📊" },
  { id: "promotion", label: "Promo", icon: "🎁", badge: true },
  { id: "account", label: "Account", icon: "👤" },
];

export default function App() {
  const [tab, setTab] = useState("home");
  const [subPage, setSubPage] = useState(null);

  const goTo = (page) => setSubPage(page);
  const goBack = () => setSubPage(null);

  const renderPage = () => {
    if (subPage === "color") return <ColorTradingPage />;
    switch (tab) {
      case "home": return <HomePage goTo={goTo} />;
      case "activity": return <ActivityPage />;
      case "promotion": return <PromotionPage />;
      case "account": return <AccountPage />;
      default: return <HomePage goTo={goTo} />;
    }
  };

  return (
    <div style={S.root}>
      {/* Top Bar */}
      <div style={S.topBar}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={S.logo}>
            <span style={S.logoFlag}>🇮🇳</span>
            <span style={S.logoText}>TIRANGA</span>
            <span style={{ fontSize: 11, color: C.textMuted, fontWeight: 500, marginLeft: 2 }}>GAMES</span>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            {subPage && (
              <button
                onClick={goBack}
                style={{
                  background: C.card,
                  border: `1px solid ${C.border}`,
                  color: C.text,
                  borderRadius: 8,
                  padding: "5px 10px",
                  cursor: "pointer",
                  fontSize: 12,
                  fontWeight: 600,
                }}
              >
                ← Back
              </button>
            )}
            <div
              style={{
                fontSize: 11,
                background: C.card,
                border: `1px solid ${C.border}`,
                padding: "4px 10px",
                borderRadius: 20,
                color: C.green,
              }}
            >
              ● LIVE
            </div>
            <div style={{ fontSize: 20 }}>🔔</div>
          </div>
        </div>
      </div>

      {/* Notice */}
      <ScrollNotice />

      {/* Wallet (on home/activity only) */}
      {!subPage && (tab === "home" || tab === "activity") && <WalletCard />}

      {/* Main Content */}
      <div style={{ overflowY: "auto" }}>{renderPage()}</div>

      {/* Bottom Nav */}
      <nav style={S.bottomNav}>
        {TABS.map((t) => {
          const active = !subPage && tab === t.id;
          return (
            <div
              key={t.id}
              style={S.navItem(active)}
              onClick={() => { setSubPage(null); setTab(t.id); }}
            >
              <span style={S.navIcon(active)}>{t.icon}</span>
              {t.badge && <span style={S.navDot} />}
              <span style={S.navLabel(active)}>{t.label}</span>
              {active && (
                <span
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: "25%",
                    right: "25%",
                    height: 2,
                    background: C.accentGold,
                    borderRadius: 2,
                  }}
                />
              )}
            </div>
          );
        })}
      </nav>
    </div>
  );
}
